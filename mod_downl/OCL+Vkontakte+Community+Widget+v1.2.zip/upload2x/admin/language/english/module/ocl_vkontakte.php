<?php

/**
 * @category  Opencart
 * @package   OCL Vkontakte Community Widget
 * @copyright Copyright (c) 2016 Opencart Lab (http://www.opencartlab.com)
 * @version	  1.2.0
 */

// Heading
$_['heading_title']      = '[OCL] Vkontakte Community Widget 1.2';

// Text
$_['text_module']        = 'Modules';
$_['text_success']       = 'Success: You have modified Vkontakte module!';
$_['text_edit']          = 'Edit Vkontakte module';
$_['text_mode0']         = 'Display community members';
$_['text_mode1']         = 'Display community name only';
$_['text_mode2']         = 'Display community feed';

// Entry
$_['entry_status']       = 'Status';
$_['entry_group_id']     = 'Group ID';
$_['entry_width']        = 'Width';
$_['entry_height']       = 'Height';
$_['entry_mode']         = 'Layout';
$_['entry_wide']         = 'Extended mode';
$_['entry_color1']       = 'Background color';
$_['entry_color2']       = 'Text color';
$_['entry_color3']       = 'Buttons color';

// Error
$_['error_permission']   = 'Warning: You do not have permission to modify Vkontakte module!';
$_['error_color']        = 'Color must be in RRGGBB format!';
$_['error_width']        = 'Width must be at least 120 or empty!';
$_['error_height']       = 'Height must be between 200 and 600 or empty!';
$_['error_group_id']     = 'Group ID required!';