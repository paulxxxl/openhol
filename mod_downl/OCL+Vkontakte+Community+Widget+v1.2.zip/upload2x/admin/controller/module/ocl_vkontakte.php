<?php

/**
 * @category  Opencart
 * @package   OCL Vkontakte Community Widget
 * @copyright Copyright (c) 2016 Opencart Lab (http://www.opencartlab.com)
 * @version   1.2.0
 */

class ControllerModuleOclVkontakte extends Controller
{
    private $error = array();
    private $name = 'ocl_vkontakte';
    private $params = array(
        'status',
        'group_id',
        'width',
        'height',
        'mode',
        'wide',
        'color1',
        'color2',
        'color3'
    );

    public function index()
    {
        $this->load->language('module/' . $this->name);

        $this->document->setTitle($this->language->get('heading_title'));

        $this->load->model('setting/setting');

        if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {
            $this->model_setting_setting->editSetting($this->name, $this->request->post);

            $this->session->data['success'] = $this->language->get('text_success');

            $this->response->redirect($this->url->link('extension/module', 'token=' . $this->session->data['token'], 'SSL'));
        }

        $data['heading_title'] = $this->language->get('heading_title');

        $data['text_edit'] = $this->language->get('text_edit');
        $data['text_enabled'] = $this->language->get('text_enabled');
        $data['text_disabled'] = $this->language->get('text_disabled');

        $data['entry_group_id'] = $this->language->get('entry_group_id');
        $data['entry_width'] = $this->language->get('entry_width');
        $data['entry_height'] = $this->language->get('entry_height');
        $data['entry_mode'] = $this->language->get('entry_mode');
        $data['entry_wide'] = $this->language->get('entry_wide');
        $data['entry_color1'] = $this->language->get('entry_color1');
        $data['entry_color2'] = $this->language->get('entry_color2');
        $data['entry_color3'] = $this->language->get('entry_color3');
        $data['entry_status'] = $this->language->get('entry_status');

        $data['button_save'] = $this->language->get('button_save');
        $data['button_cancel'] = $this->language->get('button_cancel');

        $data['breadcrumbs'] = array();

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_home'),
            'href' => $this->url->link('common/dashboard', 'token=' . $this->session->data['token'], 'SSL')
        );

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_module'),
            'href' => $this->url->link('extension/module', 'token=' . $this->session->data['token'], 'SSL')
        );

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('heading_title'),
            'href' => $this->url->link('module/.' . $this->name, 'token=' . $this->session->data['token'], 'SSL')
        );

        $data['action'] = $this->url->link('module/' . $this->name, 'token=' . $this->session->data['token'], 'SSL');
        $data['cancel'] = $this->url->link('extension/module', 'token=' . $this->session->data['token'], 'SSL');

        $data['token'] = $this->session->data['token'];

        $this->getErrors($data);
        $this->getParams($data);

        $data['modes'] = array(
            $this->language->get('text_mode0'),
            $this->language->get('text_mode1'),
            $this->language->get('text_mode2')
        );

        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');

        $this->response->setOutput($this->load->view('module/'. $this->name . '.tpl', $data));
    }

    protected function validate()
    {
        if (!$this->user->hasPermission('modify', 'module/' . $this->name)) {
            $this->error['warning'] = $this->language->get('error_permission');
        }

        if (!$this->request->post['ocl_vkontakte_group_id']) {
            $this->error['group_id'] = $this->language->get('error_group_id');
        }

        $this->checkInteger('group_id','error_group_id',true);
        $this->checkColor('color1','error_color',false,true);
        $this->checkColor('color2','error_color',false,true);
        $this->checkColor('color3','error_color',false,true);
        $this->checkInteger('width','error_width',false,true,120);
        $this->checkInteger('height','error_height',false,true,200,600);

        return !$this->error;
    }

    private function getParams(&$data)
    {
        foreach ($this->params as $paramName) {
            $fullParamName = $this->name . '_' . $paramName;
            if (isset($this->request->post[$fullParamName])) {
                $data[$fullParamName] = $this->request->post[$fullParamName];
            } else {
                $data[$fullParamName] = $this->config->get($fullParamName);
            }
        }
    }

    private function getErrors(&$data)
    {
        $data['error_warning'] = $this->getError('warning');
        foreach ($this->params as $param) {
            $data['error_' . $param] = $this->getError($param);
        }
    }

    private function getError($paramName)
    {
        if (isset($this->error[$paramName])) {
            return $this->error[$paramName];
        } else {
            return '';
        }
    }

    private function checkInteger($paramName, $errorName, $required = false, $allowEmpty = false, $min = false, $max = false)
    {
        $pattern = '/^(\d)+$/';
        $fullParamName = $this->name . '_' . $paramName;

        if (isset($this->request->post[$fullParamName])) {
            $paramValue = $this->request->post[$fullParamName];
            if (preg_match($pattern, $paramValue)) {
                $isValid = ((($min!==false&&(int)$paramValue>=$min)||$min===false)&&
                        (($max!==false&&(int)$paramValue<=$max)||$max===false));
            } else {
                $isValid = $paramValue==''&&$allowEmpty;
            }
        } else {
            $isValid = !$required;
        }

        if (!$isValid) {
            $this->error[$paramName] = $this->language->get($errorName);
        }
    }

    private function checkColor($paramName, $errorName, $required = false, $allowEmpty = false)
    {
        if ($allowEmpty) {
            $pattern = '/^([a-fA-F0-9]{6})?$/';
        } else {
            $pattern = '/^([a-fA-F0-9]{6})$/';
        }
        $fullParamName = $this->name . '_' . $paramName;
        if (isset($this->request->post[$fullParamName])) {
            $isValid = preg_match($pattern, $this->request->post[$fullParamName]);
        } else {
            $isValid = !$required;
        }

        if (!$isValid) {
            $this->error[$paramName] = $this->language->get($errorName);
        }
    }
}