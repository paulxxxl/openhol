<?php

/**
 * @category  Opencart
 * @package   OCL Vkontakte Community Widget
 * @copyright Copyright (c) 2016 Opencart Lab (http://www.opencartlab.com)
 * @version   1.2.0
 */

class ControllerModuleOclVkontakte extends Controller
{
    private $name = 'ocl_vkontakte';

    private $params = array(
        'width',
        'height',
        'mode',
        'wide',
        'color1',
        'color2',
        'color3'
    );

    public function index()
    {
        $data['group_id'] = $this->getParam('group_id');

        if ($data['group_id']) {
            $data['params'] = $this->getParams($this->params, true);

            if (file_exists(DIR_TEMPLATE . $this->config->get('config_template') . '/template/module/' . $this->name . '.tpl')) {
                return $this->load->view($this->config->get('config_template') . '/template/module/' . $this->name . '.tpl', $data);
            } else {
                return $this->load->view('default/template/module/' . $this->name . '.tpl', $data);
            }
        } else {
            return '';
        }
    }

    private function getParams($params, $returnJson = false)
    {
        $paramsArray = array();
        foreach ($params as $paramName) {
            $paramValue = $this->config->get($this->name . '_' . $paramName);
            if ($paramValue <> '') $paramsArray[$paramName] = $paramValue;
        }

        if ($returnJson) {
            return json_encode($paramsArray);
        } else {
            return $paramsArray;
        }
    }

    private function getParam($paramName)
    {
        return $this->config->get($this->name . '_' . $paramName);
    }
}