<?php

/**
 * @category  Opencart
 * @package   OCL Vkontakte Community Widget
 * @copyright Copyright (c) 2016 Opencart Lab (http://www.opencartlab.com)
 * @version	  1.2.0
 */

// Heading
$_['heading_title']      = '[OCL] ВКонтакте - Виджет для сообществ 1.2';

// Text
$_['text_module']         = 'Модули';
$_['text_success']        = 'Настройки модуля ВКонтакте успешно обновлены!';
$_['text_content_top']    = 'Верх страницы';
$_['text_content_bottom'] = 'Низ страницы';
$_['text_column_left']    = 'Левая колонка';
$_['text_column_right']   = 'Правая колонка';
$_['text_mode0']          = 'Отображать участников сообщества';
$_['text_mode1']          = 'Отображать только название сообщества';
$_['text_mode2']          = 'Отображать стену сообщества';

// Entry
$_['entry_status']       = 'Статус^:';
$_['entry_group_id']     = 'ID сообщества:';
$_['entry_dimension']    = 'Размеры (Ш x В):';
$_['entry_mode']         = 'Вид:';
$_['entry_wide']         = 'Расширенный режим:';
$_['entry_color1']       = 'Цвет фона:';
$_['entry_color2']       = 'Цвет текста:';
$_['entry_color3']       = 'Цвет кнопок:';
$_['entry_layout']       = 'Макет:';
$_['entry_position']     = 'Расположение:';
$_['entry_sort_order']   = 'Порядок сортировки:';

// Error
$_['error_permission']   = 'У Вас нет прав для управления модулем ВКонтакте!';
$_['error_color']        = 'Цвет должен быть в виде RRGGBB!';
$_['error_width']        = 'Ширина должна быть не менее 120 или пустой!';
$_['error_height']       = 'Высота должна быть от 200 до 600 или пустой!';
$_['error_group_id']     = 'Необходимо указать ID сообщества!';