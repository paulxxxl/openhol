<?php

/**
 * @category  Opencart
 * @package   OCL Vkontakte Community Widget
 * @copyright Copyright (c) 2016 Opencart Lab (http://www.opencartlab.com)
 * @version	  1.2.0
 */

// Heading
$_['heading_title']      = '[OCL] Vkontakte Community Widget 1.2';

// Text
$_['text_module']         = 'Modules';
$_['text_success']        = 'Success: You have modified Vkontakte module!';
$_['text_content_top']    = 'Content Top';
$_['text_content_bottom'] = 'Content Bottom';
$_['text_column_left']    = 'Column Left';
$_['text_column_right']   = 'Column Right';
$_['text_mode0']          = 'Display community members';
$_['text_mode1']          = 'Display community name only';
$_['text_mode2']          = 'Display community feed';

// Entry
$_['entry_status']       = 'Status:';
$_['entry_group_id']     = 'Group ID:';
$_['entry_dimension']    = 'Dimension (W x H):';
$_['entry_mode']         = 'Widget mode:';
$_['entry_wide']         = 'Extended mode:';
$_['entry_color1']       = 'Background color:';
$_['entry_color2']       = 'Text color:';
$_['entry_color3']       = 'Buttons color:';
$_['entry_layout']       = 'Layout:';
$_['entry_position']     = 'Position:';
$_['entry_sort_order']   = 'Sort Order:';

// Error
$_['error_permission']   = 'Warning: You do not have permission to modify Vkontakte module!';
$_['error_color']        = 'Color must be in RRGGBB format!';
$_['error_width']        = 'Width must be at least 120 or empty!';
$_['error_height']       = 'Height must be between 200 and 600 or empty!';
$_['error_group_id']     = 'Group ID required!';