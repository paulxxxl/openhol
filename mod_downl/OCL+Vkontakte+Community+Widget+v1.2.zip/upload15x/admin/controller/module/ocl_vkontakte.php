<?php

/**
 * @category  Opencart
 * @package   OCL Vkontakte Community Widget
 * @copyright Copyright (c) 2016 Opencart Lab (http://www.opencartlab.com)
 * @version   1.2.0
 */

class ControllerModuleOclVkontakte extends Controller
{
    private $error = array();
    private $name = 'ocl_vkontakte';
    private $params = array(
        'status',
        'group_id',
        'width',
        'height',
        'mode',
        'wide',
        'color1',
        'color2',
        'color3',
        'layout_id',
        'position',
        'sort_order'
    );

    public function index()
    {
        $this->load->language('module/' . $this->name);

        $this->document->setTitle($this->language->get('heading_title'));

        $this->load->model('setting/setting');

        if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {
            $this->model_setting_setting->editSetting($this->name, $this->request->post);
            $this->session->data['success'] = $this->language->get('text_success');
            $this->redirect($this->url->link('extension/module', 'token=' . $this->session->data['token'], 'SSL'));
        }

        $this->data['heading_title'] = $this->language->get('heading_title');

        $this->data['text_enabled'] = $this->language->get('text_enabled');
        $this->data['text_disabled'] = $this->language->get('text_disabled');
        $this->data['text_content_top'] = $this->language->get('text_content_top');
        $this->data['text_content_bottom'] = $this->language->get('text_content_bottom');
        $this->data['text_column_left'] = $this->language->get('text_column_left');
        $this->data['text_column_right'] = $this->language->get('text_column_right');

        $this->data['entry_group_id'] = $this->language->get('entry_group_id');
        $this->data['entry_dimension'] = $this->language->get('entry_dimension');
        $this->data['entry_mode'] = $this->language->get('entry_mode');
        $this->data['entry_wide'] = $this->language->get('entry_wide');
        $this->data['entry_color1'] = $this->language->get('entry_color1');
        $this->data['entry_color2'] = $this->language->get('entry_color2');
        $this->data['entry_color3'] = $this->language->get('entry_color3');
        $this->data['entry_status'] = $this->language->get('entry_status');
        $this->data['entry_layout'] = $this->language->get('entry_layout');
        $this->data['entry_position'] = $this->language->get('entry_position');
        $this->data['entry_sort_order'] = $this->language->get('entry_sort_order');

        $this->data['button_save'] = $this->language->get('button_save');
        $this->data['button_cancel'] = $this->language->get('button_cancel');
        $this->data['button_add_module'] = $this->language->get('button_add_module');
        $this->data['button_remove'] = $this->language->get('button_remove');

        $this->data['breadcrumbs'] = array();

        $this->data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_home'),
            'separator' => false,
            'href' => $this->url->link('common/dashboard', 'token=' . $this->session->data['token'], 'SSL')
        );

        $this->data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_module'),
            'separator' => ' :: ',
            'href' => $this->url->link('extension/module', 'token=' . $this->session->data['token'], 'SSL')
        );

        $this->data['breadcrumbs'][] = array(
            'text' => $this->language->get('heading_title'),
            'separator' => ' :: ',
            'href' => $this->url->link('module/' . $this->name, 'token=' . $this->session->data['token'], 'SSL')
        );

        $this->data['action'] = $this->url->link('module/' . $this->name, 'token=' . $this->session->data['token'], 'SSL');
        $this->data['cancel'] = $this->url->link('extension/module', 'token=' . $this->session->data['token'], 'SSL');

        $this->data['token'] = $this->session->data['token'];

        $this->getErrors($this->data);

        $this->data['modules'] = array();

        if (isset($this->request->post[$this->name . '_module'])) {
            $this->getModules($this->request->post[$this->name . '_module']);
        } elseif ($this->config->get($this->name . '_module')) {
            $this->getModules($this->config->get($this->name . '_module'));
        }

        $this->load->model('design/layout');

        $this->data['layouts'] = $this->model_design_layout->getLayouts();

        $this->data['modes'] = array(
            $this->language->get('text_mode0'),
            $this->language->get('text_mode1'),
            $this->language->get('text_mode2')
        );

        $this->children = array(
                'common/header',
                'common/footer'
        );

        $this->template = 'module/' . $this->name . '.tpl';
        $this->response->setOutput($this->render());
    }

    protected function validate()
    {
        if (!$this->user->hasPermission('modify', 'module/' . $this->name)) {
            $this->error['warning'] = $this->language->get('error_permission');
        }

        if (isset($this->request->post[$this->name . '_module'])&&is_array($this->request->post[$this->name . '_module'])) {
            foreach ($this->request->post[$this->name . '_module'] as $key=>$value) {
                if (!$value['group_id']) {
                    $this->error['group_id'][$key] = $this->language->get('error_group_id');
                }
                $this->checkInteger($value,$key,'group_id', 'error_group_id', true);
                $this->checkColor($value,$key,'color1', 'error_color', false, true);
                $this->checkColor($value,$key,'color2', 'error_color', false, true);
                $this->checkColor($value,$key,'color3', 'error_color', false, true);
                $this->checkInteger($value,$key,'width', 'error_width', false, true, 120);
                $this->checkInteger($value,$key,'height', 'error_height', false, true, 200, 600);
            }
        }
        return !$this->error;
    }

    private function getModules($data)
    {
        foreach ($data as $key=>$module) {
            foreach($this->params as $param) {
                $this->data['modules'][$key][$param] = (isset($module[$param]) ? $module[$param] : null);
            }
        }
    }

    private function getErrors(&$data)
    {
        $data['error_warning'] = $this->getError('warning');
        foreach ($this->params as $param) {
            $data['error_' . $param] = $this->getError($param);
        }
    }

    private function getError($paramName)
    {
        if (isset($this->error[$paramName])) {
            return $this->error[$paramName];
        } else {
            return '';
        }
    }

    private function checkInteger($module,$key,$paramName, $errorName, $required = false, $allowEmpty = false, $min = false, $max = false)
    {
        $pattern = '/^(\d)+$/';

        if (isset($module[$paramName])) {
            $paramValue = $module[$paramName];
            if (preg_match($pattern, $paramValue)) {
                $isValid = ((($min !== false && (int)$paramValue >= $min) || $min === false) &&
                            (($max !== false && (int)$paramValue <= $max) || $max === false));
            } else {
                $isValid = $paramValue==''&&$allowEmpty;
            }
        } else {
            $isValid = !$required;
        }

        if (!$isValid) {
            $this->error[$paramName][$key] = $this->language->get($errorName);
        }
    }

    private function checkColor($module,$key,$paramName, $errorName, $required = false, $allowEmpty = false)
    {
        if ($allowEmpty) {
            $pattern = '/^([a-fA-F0-9]{6})?$/';
        } else {
            $pattern = '/^([a-fA-F0-9]{6})$/';
        }
        if (isset($module[$paramName])) {
            $isValid = preg_match($pattern, $module[$paramName]);
        } else {
            $isValid = !$required;
        }

        if (!$isValid) {
            $this->error[$paramName][$key] = $this->language->get($errorName);
        }
    }
}