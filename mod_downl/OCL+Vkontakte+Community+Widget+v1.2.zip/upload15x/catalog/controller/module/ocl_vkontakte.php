<?php

/**
 * @category  Opencart
 * @package   OCL Vkontakte Community Widget
 * @copyright Copyright (c) 2016 Opencart Lab (http://www.opencartlab.com)
 * @version   1.2.0
 */

class ControllerModuleOclVkontakte extends Controller
{
    private $name = 'ocl_vkontakte';

    private $params = array(
        'width',
        'height',
        'mode',
        'wide',
        'color1',
        'color2',
        'color3'
    );

    protected function index($setting) {
        static $module = 0;

        if ($setting['group_id']) {
            $this->data['group_id'] = $setting['group_id'];
            $paramsArray = array();
            foreach ($this->params as $paramName) {
                if (isset($setting[$paramName])&&$setting[$paramName]<>'') {
                    $paramsArray[$paramName] = $setting[$paramName];
                }
            }
            $this->data['params'] = json_encode($paramsArray);
            $this->data['module'] = $module++;

            if (file_exists(DIR_TEMPLATE . $this->config->get('config_template') . '/template/module/' . $this->name . '.tpl')) {
                $this->template = $this->config->get('config_template') . '/template/module/' . $this->name . '.tpl';
            } else {
                $this->template = 'default/template/module/' . $this->name . '.tpl';
            }

            $this->render();
        }
    }
}