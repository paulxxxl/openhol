License

This code distributed under GNU General Public License version 3 (GPLv3).

Copyright (C) 2015 openweb.tech

This project based on original opencart code: https://github.com/opencart/opencart

