"Simple checkout"

This feature based on default opencart checkout page. Read more on http://openweb.tech/opencart-simple-checkout/ .

Installation

1. Do files backup

2. Copy files in opencart root directory. Next files will be replaced:
/catalog/view/theme/default/template/checkout/login.tpl
/catalog/view/theme/default/template/checkout/checkout.tpl
/catalog/view/theme/default/template/checkout/guest.tpl
/catalog/view/theme/default/template/checkout/payment_method.tpl

3. Open the: /catalog/language/english/checkout/checkout.php and change all necessary variables.