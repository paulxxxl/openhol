ALTER TABLE oc_category_description CHANGE COLUMN add_description extra_description TEXT;
ALTER TABLE  `oc_category` ADD  `hide_extra_desc` tinyint(1) NOT NULL AFTER  `top` ;