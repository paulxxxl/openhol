<?php

$_['heading_title'] = 'ильтр по цене';
$_['reset_button'] = 'Сбросить';
$_['empty_message'] = 'В этой категории нет товаров.';