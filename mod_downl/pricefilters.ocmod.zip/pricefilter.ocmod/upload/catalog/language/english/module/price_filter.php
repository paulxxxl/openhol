<?php

$_['heading_title'] = 'Price Filter';
$_['reset_button'] = 'Reset';
$_['empty_message'] = 'There are no products to list in this category.';