﻿<?php
$this->load->model('user/user_group');
$this->model_user_user_group->addPermission($this->user->getId(), 'access', 'catalog/category_mgr_lite');
$this->model_user_user_group->addPermission($this->user->getId(), 'modify', 'catalog/category_mgr_lite');
?>