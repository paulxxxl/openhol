<?php
$_['heading_title'] = 'Mega Filter Pro';
$_['name_price'] = 'Цена';
$_['name_manufacturers'] = 'Производитель';
$_['name_rating'] = 'Рейтинг';
$_['name_search'] = 'Поиск';
$_['name_stock_status'] = 'Наличие';
$_['text_button_apply'] = 'Применить';
$_['text_reset_all'] = 'Сбросить';
$_['text_show_more'] = 'Показать больше (%s)';
$_['text_show_less'] = 'Скрыть';
$_['text_display'] = 'Отображение';
$_['text_grid'] = 'Сетка';
$_['text_list'] = 'Список';
$_['text_loading'] = 'Загрузка...';
$_['text_select'] = 'Выбрать...';
$_['text_go_to_top'] = 'Вверх';
$_['text_init_filter'] = 'Инициализируйте фильтр';
$_['text_initializing'] = 'Инициализация...';
?>