﻿Installation for Opencart 2.0.x :

1. Using OCMOD

a. Sign-in to admin control panel
b. Extensions -> Extensions Installer
c. Press Upload button and open "acute_category_manager.ocmod.zip" file
d. The module is ready for work! Now you can execute it by following path: Catalog -> Acute Category Manager

If you have disabled FTP on your server or had encountered another problems with OCMOD (Extensions Installer), you may install it manually:

2. Manual Installation

a. Unzip "acute_category_manager.ocmod.zip"
b. Copy the contents of the folder "upload" to your server
c. Open "acute_category_manager.ocmod.zip" and delete content of the "upload" folder. So your archive .zip file should contain 2 files and 1 empty "upload" folder only.
d. Sign-in admin control panel
e. Extensions -> Extensions Installer
f. Press Upload button and open "acute_category_manager.ocmod.zip" file
g. The module is ready for work! Now you can execute it by following path: Catalog -> Acute Category Manager
